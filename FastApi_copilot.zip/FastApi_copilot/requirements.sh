#!/bin/bash

# Script to install dependencies for the project

# Install OpenAI
pip install openai -q

# Install langchain
pip install langchain -q

# Install retry
pip install retry -q

# Install Neo4j
pip install neo4j

# Install langchain-openai
pip install -qU langchain-openai

