from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from datetime import datetime
import atexit

import glob
import json
import os

from pprint import pprint

from langchain.graphs import Neo4jGraph

# from langchain.openai import OpenAIEmbeddings
from langchain_openai import OpenAIEmbeddings
from typing import List,Dict

# Imports from other local python files
# from NEO4J_Graph import Graph
# from FHIR_to_graph import resource_to_node, resource_to_edges
os.environ["OPENAI_API_KEY"] = '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'
os.environ["NEO4J_URI"] = 'neo4j+s://4469cbdc.databases.neo4j.io'
os.environ["NEO4J_USERNAME"] = 'neo4j'
os.environ["NEO4J_PASSWORD"] = '2mFdM_33Bx5KUR_2v2UcX7itdIJVNyZC9blMM5vHWvA'

from openai import OpenAI
import re
import json
from retry import retry
# import os
client = OpenAI()

og= Neo4jGraph(url=os.environ["NEO4J_URI"], username=os.environ["NEO4J_USERNAME"], password=os.environ["NEO4J_PASSWORD"])

embeddings = OpenAIEmbeddings(model="text-embedding-3-large") #embeddings.embed_query(text)


class agent:
  def __init__(self,client=None,model="gpt-3.5-turbo-0125",prompt_template=None):
    self.client=client
    self.model=model
    self.messages=[]
    self.prompt_template=prompt_template
  def prompt_from_template(self,template,dict1):
    try :
      return template.format(**dict1)
    except Exception as e:
      return "Not valid dictionary for the tempalte"

  def run_prompt(self,prompt)    :
    response = self.client.chat.completions.create(
         model=self.model,
         messages=[{"role": "system", "content": "You are Mutual Funds Support Copilot for OpenXfi."},
          {"role":"user","content":prompt}])
    self.messages=[]
    self.messages=[{"role":"user","content":prompt},
     {"role":"assistant","content":response.choices[0].message.content}]
    print(len(self.messages))
    return response.choices[0].message.content
  def run_are_u_sure(self,extention=None)  :
    self.messages.append({"role":"user","content":"Please Re-evaluate."+extention})
    response = self.client.chat.completions.create(
         model=self.model,
         messages=self.messages)
    self.messages=[{"role":"user","content":"Please Re-evaluate."+extention},{"role":"user","content":response.choices[0].message.content}]
    return response.choices[0].message.content
  def extract_from_string(self,string_)  :
    # end=string_.find('<')
    matches=string_
    if('json' in string_) :
      pattern = r'```json\s*([\s\S]+?)\s*```'
    # Find all matches
      matches = re.findall(pattern, string_)[0]
    elif('python' in string_):
      pattern = r'```python\s*([\s\S]+?)\s*```'
      matches = re.findall(pattern, string_)[0]

    list_string = matches[:]
    output_list = eval(list_string)
    return output_list
  @retry(exceptions=Exception, tries=3, delay=1)
  def complete_run(self,template,question:Dict,are_you_sure=None,verbose=False)  :
    prompt=self.prompt_from_template(template,question)
    o=self.run_prompt(prompt)
    if(verbose==True):
      print(o)
    # time.sleep(20)
    if(are_you_sure!=None):
      o=self.run_are_u_sure(are_you_sure)
      # time.sleep(20)
    #   print(o)
    o=self.extract_from_string(o)
    # print(o)
    return o

def chat_with_kg(agent_to_chat:agent,kg,vector_name_index,question:str,verbose=False):
  propmpt_ex_node_names=""" You are a Mutual Funds Support Copilot for Openxfi who uses Knowldege graph for refence.
  You will be propived with a question by the customer and you have to extract all the entities from the question which can be used to query the knowledge graph and extract context.
  Return output in jollowing JSON format:: json```{{'entities':['entity 1','entity 2', ...]}}```
  Question:{question} """
  Question=question
  list_of_entities=agent_to_chat.complete_run(propmpt_ex_node_names,{'question':Question})

  def name_vector_index_search(kg,node_names,index_name,k=4,verbose=False):
    ce=[]
    cypher=''

    for node in node_names:
      embedding= embeddings.embed_query(node)
      o=kg.query(f"call db.index.vector.queryNodes('{index_name}',{k},{embedding}) yield node,score return node as node")
      # print (o)
      for i in o:
        ce.append((i['node']['name'],i['node']['type']))
      # ce.append(o)
    return list(set(ce))
  out_vec=name_vector_index_search(kg,list_of_entities['entities'],vector_name_index)
  if(verbose==True):print('Nearest nodes::',out_vec)

  def extraData(kg,node_names):
    output=[]
    cypher ="""MATCH (base_node)-[relationship]-(connected_node)
      WHERE base_node.name = '{node_name}' and base_node.type='{type}'
      RETURN base_node.name, type(relationship) AS relationship_name, connected_node.name, connected_node.type
        """
    base_node_cypher="""MATCH (base_node) WHERE base_node.name = '{node_name}' and base_node.type='{type}' RETURN base_node.name,base_node.type,base_node.text """
    i=0
    for name,type_ in node_names:
      base_d=kg.query(base_node_cypher.format(**{'node_name':name,'type':type_}))
      output.append(base_d)
      o=kg.query(cypher.format(**{'node_name':name,'type':type_}))
      output.append(o)
    return output

  ex_data=extraData(kg,out_vec)
  if(verbose==True):print('refernce data::',ex_data)

  propmpt_ex_node_names=""" You are a Mutual Funds Support Copilot for Openxfi who uses Knowldege graph for refence.
  You were provided with a question by the customer and you had to extract all the entities from the question which could be used to query the knowledge graph and extract context.
  After that those were used to query graph and get context.
  Following is the context extracted. All the relationships the node has with other nodes is extracted and given in context in JSON format. Use it to answer the question.
  Answer the question based on context in Natual Language only.

  Question:{question}
  \nContext::\n{context}
  Important: Answer truthfully and to the point and just say I dont know if you do not.Do not say 'Based on context provided' EVER. Instead talk like a human would .
  """

  output=agent_to_chat.run_prompt(agent_to_chat.prompt_from_template(propmpt_ex_node_names,{'question':Question,'context':ex_data}))
  return output


agent_to_chat=agent(client)
# answer=chat_with_kg(agent_to_chat,og,'index_name_emb','What are Arbitrage Mutual Funds')
# print(answer)

app = FastAPI()

class RequestItem(BaseModel):
    Customer_id: str
    Customer_query: str
try:
    with open('all_chats.json', 'r') as file:
        all_chats = json.load(file)
    print(all_chats)
except Exception as e:
  all_chats={}
  print('No prvious chat history.')

@app.post("/Answer_query/")
async def process_request(item: RequestItem):
    # Here you can process the received request

    # answer=chat_with_kg(agent_to_chat,og,'index_name_emb','What are Arbitrage Mutual Funds')
    req=item.dict()
    if(req['Customer_id'] not in all_chats.keys()):
        all_chats[req['Customer_id']]={}
    
    all_chats[req['Customer_id']][str(datetime.now())]=['request',req['Customer_query']]
    answer=chat_with_kg(agent_to_chat,og,'index_name_emb',req['Customer_query'])
    all_chats[req['Customer_id']][str(datetime.now())]=['response',answer]

    return {"message": "Request received and processed successfully", "response": {'Answer':answer}}
def save_on_exit():
    with open('all_chats.json', 'w') as file:
        json.dump(all_chats, file, indent=4)

if __name__ == "__main__":
    import uvicorn
    atexit.register(save_on_exit)
    uvicorn.run(app, host="0.0.0.0", port=3000)
