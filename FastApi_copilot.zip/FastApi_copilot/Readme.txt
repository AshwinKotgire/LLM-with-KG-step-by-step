#Following is the structure of the folder:
1. requirements.sh has the list of requirements to install of python
2. Fast_api_copilot.py Main file holding the uvicorn server for fast APi for responding to chat messages by users hoping to use copilot.
3. all_chats.json holds the data of all the chats carried out by all the users. This should later be changed to a more versatile database like mongodb

#How to run:
1. install all the requirements from requirements.sh file preferably in a seperate conda environment
    bash requirements.sh
2.  python Fast_api_copilot.py will run the fastAPI server on http://0.0.0.0:3000

#To communicate with the server
Use a POST request at " http://0.0.0.0:3000/Answer_query/ "
of the fromat : 
    {
        "Customer_id": "some_id",
        "Customer_query": "Query"
    }
    